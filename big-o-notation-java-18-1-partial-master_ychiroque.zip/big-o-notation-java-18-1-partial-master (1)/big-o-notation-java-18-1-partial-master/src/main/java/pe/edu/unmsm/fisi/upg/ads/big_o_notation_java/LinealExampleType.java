package pe.edu.unmsm.fisi.upg.ads.big_o_notation_java;

public enum LinealExampleType {
	Loop, Search, Factorial;
}
